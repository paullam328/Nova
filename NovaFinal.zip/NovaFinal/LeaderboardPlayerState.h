// Copywrite Shapeshifter 2019

#pragma once

#include "CoreMinimal.h"
#include "FighterPlayerState.h"
#include "LeaderboardPlayerState.generated.h"

/**
 * 
 */
UCLASS()
class NOVAFINAL_API ALeaderboardPlayerState : public AFighterPlayerState
{
	GENERATED_BODY()
	
};
