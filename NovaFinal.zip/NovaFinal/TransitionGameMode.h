// Copywrite Shapeshifter 2019

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameMode.h"
#include "TransitionGameMode.generated.h"

/**
 * 
 */
UCLASS()
class NOVAFINAL_API ATransitionGameMode : public AGameMode
{
	GENERATED_BODY()


	ATransitionGameMode();
};
