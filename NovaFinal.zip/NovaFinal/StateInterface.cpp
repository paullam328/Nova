// Copywrite Shapeshifter 2019

#include "StateInterface.h"

// Add default functionality here for any IStateInterface functions that are not pure virtual.
