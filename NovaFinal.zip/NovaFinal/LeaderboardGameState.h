// Copywrite Shapeshifter 2019

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameState.h"
#include "LeaderboardGameState.generated.h"

/**
 * 
 */
UCLASS()
class NOVAFINAL_API ALeaderboardGameState : public AGameState
{
	GENERATED_BODY()
	
};
