// Copywrite Shapeshifter 2019

#include "DemarkCharacterSelectActor.h"

// Sets default values
ADemarkCharacterSelectActor::ADemarkCharacterSelectActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ADemarkCharacterSelectActor::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ADemarkCharacterSelectActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

