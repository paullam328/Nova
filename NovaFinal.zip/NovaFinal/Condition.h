// Copywrite Shapeshifter 2019

#pragma once

#include "CoreMinimal.h"
#include "Condition.generated.h"

/**
 * 
 */
UENUM()
enum class ECondition : uint8
{
	Undecided = 0,
	Win,
	Lose
};
