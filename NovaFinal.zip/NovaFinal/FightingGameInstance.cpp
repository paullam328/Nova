// Copywrite Shapeshifter 2019

#include "FightingGameInstance.h"

//NOTE: THIS GAME INSTANCE IS CORRUPTED