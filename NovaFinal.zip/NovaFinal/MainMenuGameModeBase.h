// Copywrite Shapeshifter 2019

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "MainMenuGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class NOVAFINAL_API AMainMenuGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
