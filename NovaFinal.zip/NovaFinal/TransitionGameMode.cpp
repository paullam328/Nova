// Copywrite Shapeshifter 2019

#include "TransitionGameMode.h"

ATransitionGameMode::ATransitionGameMode()
{
	bUseSeamlessTravel = true;
}