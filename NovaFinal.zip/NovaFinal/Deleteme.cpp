// Copywrite Shapeshifter 2019

#include "Deleteme.h"

#pragma optimize("", off)
bool ADeleteme::InputKey(FKey Key, EInputEvent EventType, float AmountDepressed, bool bGamepad)
{


	return true;
}
#pragma optimize("", on)