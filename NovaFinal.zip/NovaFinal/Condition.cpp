// Copywrite Shapeshifter 2019

#include "Condition.h"
