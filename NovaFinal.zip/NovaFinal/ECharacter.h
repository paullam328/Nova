// Copywrite Shapeshifter 2019

#pragma once
#include "CoreMinimal.h"
#include "ECharacter.generated.h"


/**
 *
 */

UENUM()
enum class ECharacter : uint8
{
	//Index + 1;
	Invalid = 0,
	Demark,
	Maskium,
};
